
# Rule engine

This example republish each message received to different topics.
Run it with `node broker.js`

