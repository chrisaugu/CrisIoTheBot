
module.exports = {
  port: 4884,
  backend: {
    type: "mqtt",
    port: 4883,
    prefix: "/s"
  }
};
