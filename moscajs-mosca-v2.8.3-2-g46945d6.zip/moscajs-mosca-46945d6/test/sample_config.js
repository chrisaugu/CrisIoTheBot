module.exports = {
  port: 2883,
  backend: {
    type: "mqtt",
    port: 3833
  }
};
